package com.loktv.hookpro.core;

import de.robv.android.xposed.XSharedPreferences;

/**
 * مفاتيح الميزات (تتحكم بها واجهة الإعدادات).
 *
 * <p>الافتراضي = الكل مفعّل. يحاول طرف الهوك قراءة اختيارات المستخدم عبر
 * XSharedPreferences؛ إن تعذّر (وضع بدون روت غالباً) تبقى الافتراضات —
 * لا كراش ولا تعطّل في أي حال.
 */
public final class FeatureFlags {

    public static final String PREFS_NAME = "loktv_hook_prefs";

    public static final String K_PREFS   = "f_prefs";
    public static final String K_JSON    = "f_json";
    public static final String K_TEXT    = "f_text";
    public static final String K_BUNDLE  = "f_bundle";
    public static final String K_VIP     = "f_vip";
    public static final String K_DETECT  = "f_detect";
    public static final String K_NATIVE  = "f_native";

    public static volatile boolean prefs  = true;
    public static volatile boolean json   = true;
    public static volatile boolean text   = true;
    public static volatile boolean bundle = true;
    public static volatile boolean vip     = true;
    public static volatile boolean detect = true;
    public static volatile boolean nativeLog = true;

    private static volatile boolean loaded = false;

    /** تُستدعى مرة واحدة في بداية كل تمريرة تفعيل. */
    public static void load() {
        if (loaded) return;
        loaded = true;
        Safe.run("flags", new Safe.Block() {
            @Override public void run() throws Throwable {
                XSharedPreferences xp =
                        new XSharedPreferences(Config.MODULE_PACKAGE, PREFS_NAME);
                boolean hasFile = false;
                try {
                    hasFile = xp.getFile().exists();
                } catch (Throwable ignored) {
                    hasFile = false;
                }
                if (!hasFile) {
                    XLog.i("flags: module prefs unreadable → defaults (all ON)");
                    return;
                }
                try {
                    xp.reload();
                } catch (Throwable ignored) {}
                prefs     = xp.getBoolean(K_PREFS, true);
                json      = xp.getBoolean(K_JSON, true);
                text      = xp.getBoolean(K_TEXT, true);
                bundle    = xp.getBoolean(K_BUNDLE, true);
                vip       = xp.getBoolean(K_VIP, true);
                detect    = xp.getBoolean(K_DETECT, true);
                nativeLog = xp.getBoolean(K_NATIVE, true);
                XLog.i("flags: prefs=" + prefs + " json=" + json + " text=" + text
                        + " bundle=" + bundle + " vip=" + vip
                        + " detect=" + detect + " native=" + nativeLog);
            }
        });
    }

    private FeatureFlags() {}
}
