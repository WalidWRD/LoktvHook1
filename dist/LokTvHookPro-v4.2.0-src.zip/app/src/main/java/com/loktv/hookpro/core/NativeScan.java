package com.loktv.hookpro.core;

import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * بصمة Native (تشخيصية + مراقبة فقط — لا حجب ولا تعديل):
 *  1) جرد ملفات lib/*.so من APK الهدف ومطابقتها ببصمات VIP/Detect (بلا تحميل).
 *  2) مراقبة System.loadLibrary/System.load (observe-only) لمعرفة ما يُحمَّل فعلاً.
 *
 * Xposed لا يخطَف كود native مباشرة — هذه الطبقة تخبرنا أين ننظر عند الصيانة.
 */
public final class NativeScan {

    private static volatile boolean spiesInstalled = false;
    private static final int MAX_LISTED = 20;
    private static final int MAX_ENTRIES = 4000;

    /** جرد .so من APK — آمن: قراءة Zip فقط. */
    public static void report(final File apk) {
        Safe.run("native-report", new Safe.Block() {
            @Override public void run() throws Throwable {
                if (apk == null || !apk.isFile()) {
                    XLog.w("native: no apk, skipping inventory");
                    return;
                }
                int total = 0;
                List<String> vipHits = new ArrayList<String>();
                List<String> detectHits = new ArrayList<String>();
                ZipFile zf = null;
                try {
                    zf = new ZipFile(apk);
                    Enumeration<? extends ZipEntry> it = zf.entries();
                    while (it.hasMoreElements()) {
                        ZipEntry e = it.nextElement();
                        String n = e.getName();
                        if (!n.startsWith("lib/") || !n.endsWith(".so")) continue;
                        total++;
                        if (total > MAX_ENTRIES) break;
                        String base = n.substring(n.lastIndexOf('/') + 1).toLowerCase(Locale.US);
                        if (Config.isVipName(base)) {
                            if (vipHits.size() < MAX_LISTED) vipHits.add(n);
                        } else if (Config.isDetectName(base)) {
                            if (detectHits.size() < MAX_LISTED) detectHits.add(n);
                        }
                    }
                } finally {
                    if (zf != null) {
                        try { zf.close(); } catch (Throwable ignored) {}
                    }
                }
                XLog.i("native: .so total=" + total
                        + " vipHits=" + vipHits.size() + " detectHits=" + detectHits.size());
                for (int i = 0; i < vipHits.size(); i++) {
                    XLog.i("native vip-lib: " + vipHits.get(i));
                }
                for (int i = 0; i < detectHits.size(); i++) {
                    XLog.i("native detect-lib: " + detectHits.get(i));
                }
            }
        });
    }

    /** مراقبة التحميل — after فقط (لا نمنع أي مكتبة من التحميل أبداً). */
    public static void installLoadSpies() {
        if (spiesInstalled) return;
        spiesInstalled = true;
        Safe.run("native-spy-lib", new Safe.Block() {
            @Override public void run() throws Throwable {
                XposedHelpers.findAndHookMethod(System.class, "loadLibrary", String.class,
                        new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        try {
                            XLog.d("native load: " + p.args[0]);
                        } catch (Throwable ignored) {}
                    }
                });
            }
        });
        Safe.run("native-spy-load", new Safe.Block() {
            @Override public void run() throws Throwable {
                XposedHelpers.findAndHookMethod(System.class, "load", String.class,
                        new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        try {
                            XLog.d("native load(path): " + p.args[0]);
                        } catch (Throwable ignored) {}
                    }
                });
            }
        });
        XLog.i("native: load spies installed (observe-only)");
    }

    private NativeScan() {}
}
