package com.loktv.hookpro.ui;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loktv.hookpro.core.Config;
import com.loktv.hookpro.core.FeatureFlags;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/**
 * شاشة الموديول: مفاتيح الميزات + التشخيص + اللوج.
 *
 * <p>ملاحظة: تُقرأ الاختيارات من طرف الهوك عبر XSharedPreferences.
 * في وضع LSPosed (روت) تُطبَّق فوراً. في الوضع بدون روت (LSPatch/NPatch/HKP)
 * قد لا تُقرأ — عندها تبقى الافتراضات (الكل مفعّل) ويُسجَّل ذلك في اللوج.
 */
public final class SettingsActivity extends Activity {

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(FeatureFlags.PREFS_NAME, Context.MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("LokTvHookPro v" + Config.VERSION_NAME);
        title.setTextSize(20);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText(
                "API " + Config.MIN_SDK + " → " + Config.MAX_SDK + "\n"
                + "Package: " + getPackageName() + "\n"
                + "Log: <cacheDir>/" + Config.LOG_FILE + "\n"
                + "Kill-switch: create <cacheDir>/" + Config.KILLSWITCH_FILE);
        info.setPadding(0, pad / 2, 0, pad);
        root.addView(info);

        TextView featTitle = new TextView(this);
        featTitle.setText("الميزات (تُطبَّق من التمريرة التالية):");
        featTitle.setPadding(0, 0, 0, pad / 4);
        root.addView(featTitle);

        addToggle(root, "بوابة SharedPreferences ‏(VIP booleans/ints)",
                FeatureFlags.K_PREFS, true);
        addToggle(root, "طبقة JSONObject",
                FeatureFlags.K_JSON, true);
        addToggle(root, "طبقة TextView ‏(تسميات VIP)",
                FeatureFlags.K_TEXT, true);
        addToggle(root, "طبقة Bundle/Intent extras",
                FeatureFlags.K_BUNDLE, true);
        addToggle(root, "هوكات البصمة VIP ‏(درجة A/B)",
                FeatureFlags.K_VIP, true);
        addToggle(root, "تعطيل الكشف ‏(روت/VPN/تصحيح)",
                FeatureFlags.K_DETECT, true);
        addToggle(root, "بصمة Native ‏(جرد .so + مراقبة التحميل)",
                FeatureFlags.K_NATIVE, true);

        TextView logTitle = new TextView(this);
        logTitle.setText("اللوج:");
        logTitle.setPadding(0, pad / 2, 0, pad / 4);
        root.addView(logTitle);

        TextView log = new TextView(this);
        log.setTextSize(10);
        log.setText(readLog());
        ScrollView sv = new ScrollView(this);
        sv.addView(log, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(sv);

        setContentView(root);
    }

    private void addToggle(LinearLayout root, String label,
                           final String key, boolean def) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setChecked(prefs.getBoolean(key, def));
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton buttonView, boolean checked) {
                try {
                    prefs.edit().putBoolean(key, checked).apply();
                    makePrefsReadable();
                } catch (Throwable ignored) {}
            }
        });
        root.addView(cb);
    }

    /** محاولة جعل ملف الإعدادات مقروءاً لطرف الهوك (تنجح مع روت، harmless بدونه). */
    private void makePrefsReadable() {
        try {
            File dir = getFilesDir().getParentFile();
            if (dir == null) return;
            File f = new File(dir, "shared_prefs/" + FeatureFlags.PREFS_NAME + ".xml");
            f.setReadable(true, false);
        } catch (Throwable ignored) {}
    }

    private String readLog() {
        try {
            File f = new File(getCacheDir(), Config.LOG_FILE);
            if (!f.exists()) return "(no log yet)";
            StringBuilder sb = new StringBuilder();
            BufferedReader r = null;
            try {
                r = new BufferedReader(new FileReader(f));
                String line;
                int n = 0;
                while ((line = r.readLine()) != null && n++ < 400) {
                    sb.append(line).append('\n');
                }
            } finally {
                if (r != null) {
                    try { r.close(); } catch (Throwable ignored) {}
                }
            }
            return sb.toString();
        } catch (Throwable t) {
            return "(error: " + t + ")";
        }
    }
}
