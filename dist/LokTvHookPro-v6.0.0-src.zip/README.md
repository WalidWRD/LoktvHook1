# LokTvHookPro v6.0.0

> `LokTvHookPro 6.0.0 | VIP unlock + prefs/JSON/TextView | API21-35 | آمن | روت/بدون روت`

## بطاقة الموديول

| البند | القيمة |
|---|---|
| الاسم | LokTvHookPro |
| الإصدار | 6.0.0 (versionCode 600) |
| الحزمة | `com.loktv.hookpro` |
| أندرويد | API 21 (5.0) → API 35 (15) |
| المدخل القديم | `HookEntry` ← `assets/xposed_init` (legacy api 82) |
| المدخل الحديث | `MainHook` ← `META-INF/xposed/java_init.list` (libxposed **102.0.0**) |
| روت | LSPosed / EdXposed |
| بدون روت | NPatch / LSPatch / HKPatcher |

## المخرجات الجاهزة

| الملف | الوصف |
|---|---|
| `dist/LokTvHookPro-v6.0.0.apk` | الموديول موقّعاً (v1+v2+v3) — ثبّته مباشرة فوق v4.2.0 (نفس التوقيع) |
| `dist/LokTvHookPro-v6.0.0-src.zip` | السورس كود الكامل — يُبنى بـ `./build.sh` (العدسات مُورَّدة في `app/libs`) |
| `docs/ANALYSIS_LokTvHookPro_v6.0.0.md` | ملف التحليل والنتائج (مع ملفي v4.x يغني عن إعادة التحليل) |
| `dist/LokTvHookPro-v4.*` | الجيل السابق (باقٍ للمرجع) |

## الجديد في v6.0.0

- **مدخل مزدوج**: `MainHook` (libxposed 102) + `HookEntry` (legacy) — نفس السياسة، والفريمورك يختار.
- **HookEngine مستخرج**: كل `setResult` عبر `Safe.coerceReturn` (استحالة ClassCastException) + جرد الوراثة.
- **منع re-arm**: `tryArm` + أعلام once — لا ضجيج ولا عمل مكرر عبر التمريرات.
- **قيم الانتهاء 2100** لأسماء `expire/expiry/validuntil/endtime`.
- **زر مفتاح الطوارئ** في الشاشة + `hook_config.json` مشحون + دعم API 21+.

## البناء من السورس (أمر واحد)

```bash
./build.sh
# الناتج: dist/LokTvHookPro-v6.0.0.apk
```

المتطلبات: JDK 17 + Android SDK (يقرأ `ANDROID_HOME`) + إنترنت أول مرة فقط.
كلمة سر المفتاح الافتراضية `loktv2026` (غيّرها عبر `LOKTV_KEY_PASS=... ./build.sh`) —
**احتفظ بملف `keystore/` للتحديثات** (نفس التوقيع شرط للتحديث فوق النسخة).

## التثبيت

### بدون روت (NPatch / LSPatch / HKP)
1. ثبّت APK الموديول وافتحه مرة (اختر الميزات + زر الطوارئ يعمل هنا فوراً).
2. فعّل الموديول في المدير.
3. Local patch ← APK الهدف ← Patch ← Install.
4. احذف نسخة الهدف الأصلية (التوقيع مختلف).

### روت (LSPosed)
1. ثبّت APK الموديول (ترقية مباشرة فوق v4.2.0 — نفس التوقيع).
2. فعّله في LSPosed وعلّم **أي** حزمة هدف (لا قيد على الاسم).
3. Force stop للهدف ثم افتحه.
4. الطوارئ في وضع روت: أنشئ `<cacheDir>/loktv_hook_safe.flag` في تطبيق **الهدف**
   (مدير ملفات بروت) — زر الشاشة يكتب في cache الموديول فقط.

## كيف يعمل (باختصار)

- **بلا أسماء ثابتة**: `classLoader` + انعكاس + بصمة
  (اسم الصنف + توقيع الدالة: boolean/int/String/void) + جرد DEX من جدول السلاسل.
- **مضغوط/محمي**: جامع لوادر من 5 مصادر + سلسلة تفعيل (2ث→31ث) تلتقط الأصناف بعد فك الضغط.
- **بلا كراش**: فلتر بنية تحتية (`pairip`/`fancybypass`/...) + كل شيء داخل `Safe.run` +
  `coerceReturn` + حدود عدد/زمن + kill-switch.
- **قابل للصيانة**: السياسة في `core/Config.java`، الربط القديم `HookEngine.java`،
  الربط الحديث `ModernEngine.java` (مرآة)، الميزات `FeatureFlags.java` — انظر `docs/ANALYSIS_*`.

## التحقق من البناء

```bash
apksigner verify --print-certs dist/LokTvHookPro-v6.0.0.apk   # v1+v2+v3
jarsigner -verify dist/LokTvHookPro-v6.0.0.apk                # v1/JAR
unzip -p dist/LokTvHookPro-v6.0.0.apk META-INF/xposed/java_init.list
unzip -p dist/LokTvHookPro-v6.0.0.apk assets/xposed_init
```
