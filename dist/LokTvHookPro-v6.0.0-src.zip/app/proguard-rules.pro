# Keep the Xposed entry points and all hook classes (accessed via reflection).
-keep class com.loktv.hookpro.HookEntry { *; }
-keep class com.loktv.hookpro.MainHook { *; }
-keep class com.loktv.hookpro.core.** { *; }
-keep class com.loktv.hookpro.ui.** { *; }
-dontwarn de.robv.android.xposed.**
-dontwarn io.github.libxposed.**
