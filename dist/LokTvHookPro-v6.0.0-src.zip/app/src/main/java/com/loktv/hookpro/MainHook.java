package com.loktv.hookpro;

import android.util.Log;

import com.loktv.hookpro.core.ModernEngine;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

/**
 * المدخل الحديث (libxposed API 102) — يُعلن عبر META-INF/xposed/java_init.list.
 *
 * <p>نفس سياسة HookEntry (legacy): بصمة + انعكاس، بلا أسماء ثابتة، لا كراش،
 * أي حزمة، API 21→35 بتسامح. كل القرارات مشتركة (Config/DexNames/FeatureFlags)،
 * وميكانيكا الهوك فقط عبر واجهة libxposed الحديثة (انظر ModernEngine).
 */
public class MainHook extends XposedModule {

    @Override
    public void onPackageLoaded(XposedModuleInterface.PackageLoadedParam lp) {
        try {
            ModernEngine.onPackageLoaded(this, lp);
        } catch (Throwable t) {
            try {
                log(Log.WARN, "LokTvHookPro", "MainHook guard: " + t);
            } catch (Throwable ignored) {}
        }
    }
}
