package com.loktv.hookpro.core;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;

/**
 * محرك الهوك الآمن (مسار legacy).
 *
 * <p>نفس سياسة UnlockEngine v4.x (بصمة اسم الصنف + توقيع الدالة)، مع:
 * <ul>
 *   <li>جرد الدوال عبر الوراثة (Reflect.allMethods) — يلتقط دوال VIP الموروثة.</li>
 *   <li>كل setResult عبر Safe.coerceReturn — يستحيل ClassCastException.</li>
 *   <li>منع التكرار بتوقيع الدالة + مفاتيح FeatureFlags.</li>
 * </ul>
 */
public final class HookEngine {

    private final AtomicInteger hookCount = new AtomicInteger(0);
    private final AtomicInteger classCount = new AtomicInteger(0);
    private final AtomicInteger targeted = new AtomicInteger(0);
    private final Set<String> hookedClasses = new HashSet<String>();
    private final Set<String> seenSignatures = new HashSet<String>();

    public int hookCount() { return hookCount.get(); }
    public int classCount() { return classCount.get(); }
    public int targeted() { return targeted.get(); }

    /** الدرجة: 1 = VIP صريح، 2 = كشف (للتعطيل)، 0 = تجاهل. */
    public static int classify(String className) {
        if (className == null) return 0;
        String lower = className.toLowerCase(Locale.US);
        if (Config.isVipName(lower)) return 1;
        if (Config.isDetectName(lower)) return 2;
        return 0;
    }

    /** حل الاسم عبر الـ loader ثم الربط حسب الدرجة — كل الفحوصات هنا. */
    public void hookClassByName(String name, ClassLoader cl) {
        if (name == null || cl == null) return;
        synchronized (hookedClasses) {
            if (hookedClasses.contains(name)) return;
        }
        Class<?> k;
        try {
            k = Class.forName(name, false, cl);
        } catch (Throwable t) {
            return;
        }
        hookClass(k);
    }

    public void hookClass(Class<?> k) {
        if (k == null) return;
        String name = k.getName();
        if (Config.isInfrastructure(name)) return;
        if (k.isInterface() || Modifier.isAbstract(k.getModifiers())) return;
        synchronized (hookedClasses) {
            if (hookedClasses.contains(name)) return;
        }

        int tier = classify(name.toLowerCase(Locale.US));
        if (tier == 2 && !FeatureFlags.detect) return;
        if (tier == 1 && !FeatureFlags.vip) return;
        if (tier == 0) return;

        int added = 0;
        int perClass = 0;
        List<Method> methods = Reflect.allMethods(k);
        for (int i = 0; i < methods.size(); i++) {
            Method m = methods.get(i);
            if (perClass >= Config.MAX_HOOKS_PER_CLASS) break;
            if (hookCount.get() >= Config.MAX_HOOKS) return;
            if (!canHook(m)) continue;

            XC_MethodHook handler = buildHandler(m, tier);
            if (handler == null) continue;
            try {
                XposedBridge.hookMethod(m, handler);
                added++;
                perClass++;
                hookCount.incrementAndGet();
            } catch (Throwable ignored) {}
        }

        if (added > 0) {
            synchronized (hookedClasses) {
                hookedClasses.add(name);
            }
            targeted.incrementAndGet();
            XLog.i("hooked class: " + name + " hooks+=" + added);
        }
    }

    private boolean canHook(Method m) {
        if (m == null) return false;
        int mod = m.getModifiers();
        if (Modifier.isAbstract(mod)) return false;
        if (Modifier.isNative(mod)) return false;
        if (Config.isProtectedMethodName(m.getName())) return false;
        String sig;
        try {
            sig = m.getDeclaringClass().getName() + "#" + m.getName()
                    + Arrays.toString(m.getParameterTypes());
        } catch (Throwable t) {
            return false;
        }
        synchronized (seenSignatures) {
            return seenSignatures.add(sig);
        }
    }

    /**
     * بناء المعالج حسب الدرجة والتوقيع:
     *  tier=2 (كشف): boolean=false، أرقام=0، دوال check/detect/call=noop.
     *  tier=1 (VIP): boolean=true، int/long=99 (انتهاء=2100)، نص VIP، void=إجبار الحقول.
     */
    private XC_MethodHook buildHandler(Method m, int tier) {
        Class<?> rt;
        String mnl;
        try {
            rt = m.getReturnType();
            mnl = m.getName().toLowerCase(Locale.US);
        } catch (Throwable t) {
            return null;
        }

        if (tier == 2) {
            if (rt == boolean.class) return forcedResult(false);
            if (rt == int.class || rt == long.class) return forcedResult(0L);
            if (mnl.contains("call") || mnl.contains("check") || mnl.contains("detect")) {
                return neutralize();
            }
            return null;
        }

        // tier == 1 — يتطلب مفتاح vip للدرجة B (خارج أصناف VIP الصريحة لا نصل هنا أصلاً)
        if (rt == boolean.class) return forcedResult(true);
        if (rt == int.class || rt == long.class) {
            return forcedResult(isExpiryMethod(mnl)
                    ? Config.VALUE_LONG_EXPIRE : Config.VALUE_LONG_DEFAULT);
        }
        if (rt == String.class && isVipMethodName(mnl)) {
            return forcedResult(Config.VALUE_STRING_VIP);
        }
        if (rt == void.class && isVipMethodName(mnl)) {
            return forceFieldsAfter();
        }
        return null;
    }

    /** هوك الدرجة B: يُستدعى للأصناف غير المصنفة عندما تحمل الدالة اسم VIP. */
    public void hookClassGradeB(Class<?> k) {
        if (k == null || !FeatureFlags.vip) return;
        String name = k.getName();
        if (Config.isInfrastructure(name)) return;
        if (k.isInterface() || Modifier.isAbstract(k.getModifiers())) return;
        synchronized (hookedClasses) {
            if (hookedClasses.contains(name)) return;
        }
        int added = 0;
        int perClass = 0;
        List<Method> methods = Reflect.allMethods(k);
        for (int i = 0; i < methods.size(); i++) {
            Method m = methods.get(i);
            if (perClass >= Config.MAX_HOOKS_PER_CLASS) break;
            if (hookCount.get() >= Config.MAX_HOOKS) return;
            if (!canHook(m)) continue;
            String mnl;
            Class<?> rt;
            try {
                mnl = m.getName().toLowerCase(Locale.US);
                rt = m.getReturnType();
            } catch (Throwable t) {
                continue;
            }
            if (!isVipMethodName(mnl)) continue;
            XC_MethodHook handler = null;
            if (rt == boolean.class) {
                handler = forcedResult(true);
            } else if (rt == int.class || rt == long.class) {
                handler = forcedResult(isExpiryMethod(mnl)
                        ? Config.VALUE_LONG_EXPIRE : Config.VALUE_LONG_DEFAULT);
            }
            if (handler == null) continue;
            try {
                XposedBridge.hookMethod(m, handler);
                added++;
                perClass++;
                hookCount.incrementAndGet();
            } catch (Throwable ignored) {}
        }
        if (added > 0) {
            synchronized (hookedClasses) {
                hookedClasses.add(name);
            }
            targeted.incrementAndGet();
            XLog.i("hooked class: " + name + " hooks+=" + added);
        }
    }

    static boolean isVipMethodName(String lower) {
        return lower.contains("vip") || lower.contains("premium")
                || lower.contains("subscri") || lower.contains("member")
                || lower.contains("entitle") || lower.contains("paid")
                || (lower.contains("pro") && !lower.contains("process"))
                || lower.contains("gate") || lower.contains("tier")
                || lower.contains("expire") || lower.contains("expiry")
                || lower.contains("isvip") || lower.contains("ispro");
    }

    static boolean isExpiryMethod(String lowerMethod) {
        return Config.isExpiryName(lowerMethod);
    }

    /** فرض قيمة عبر coerceReturn — آمن نوعياً دائماً. */
    static XC_MethodHook forcedResult(final Object value) {
        return new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    if (p.method instanceof Method) {
                        p.setResult(Safe.coerceReturn((Method) p.method, value));
                    } else {
                        p.setResult(value);
                    }
                } catch (Throwable t) {
                    XLog.w("forcedResult: " + t);
                }
            }
        };
    }

    /** تحييد دالة كشف (check/detect/call) حسب نوع إرجاعها. */
    static XC_MethodHook neutralize() {
        return new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    if (!(p.method instanceof Method)) return;
                    Method m = (Method) p.method;
                    Class<?> rt = m.getReturnType();
                    if (rt == void.class) return;
                    if (rt == boolean.class) { p.setResult(false); return; }
                    if (rt == int.class) { p.setResult(0); return; }
                    if (rt == long.class) { p.setResult(0L); return; }
                    p.setResult(Safe.coerceReturn(m, null));
                } catch (Throwable t) {
                    XLog.w("neutralize: " + t);
                }
            }
        };
    }

    /** دوال void ذات اسم VIP: إجبار الحقول المنطقية بعد التنفيذ. */
    static XC_MethodHook forceFieldsAfter() {
        return new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Object self = p.thisObject;
                    if (self == null) return;
                    Class<?> k = self.getClass();
                    while (k != null && k != Object.class) {
                        Field[] fields;
                        try {
                            fields = k.getDeclaredFields();
                        } catch (Throwable t) {
                            break;
                        }
                        for (int i = 0; i < fields.length; i++) {
                            final Field f = fields[i];
                            if (Modifier.isStatic(f.getModifiers())) continue;
                            if (f.getType() != boolean.class) continue;
                            Safe.run("force." + f.getName(), new Safe.Block() {
                                @Override public void run() throws Throwable {
                                    f.setAccessible(true);
                                    f.setBoolean(p.thisObject, true);
                                }
                            });
                        }
                        k = k.getSuperclass();
                    }
                } catch (Throwable t) {
                    XLog.w("forceFields: " + t);
                }
            }
        };
    }
}
