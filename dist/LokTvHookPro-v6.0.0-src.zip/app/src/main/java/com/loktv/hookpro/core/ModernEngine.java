package com.loktv.hookpro.core;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import io.github.libxposed.api.XposedInterface;
import io.github.libxposed.api.XposedModuleInterface;

/**
 * محرك المسار الحديث (libxposed 102) — نفس سياسة HookEngine/UnlockEngine،
 * لكن ميكانيكا الهوك عبر {@link XposedInterface#hook} + {@code Chain}.
 *
 * <p>حدود معروفة للمسار الحديث (موثقة لا مخفية):
 * <ul>
 *   <li>لا اسم عملية في PackageLoadedParam — فلتر العمليات غير ممكن؛
 *       منع التكرار يتم بأعلام once + تسليح اللوادر + عدم التكرار بالتوقيع.</li>
 *   <li>دوال الكشف ذات إرجاع كائن: نكتفي بالمراقبة (proceed) بدل التحييد —
 *       أسلم من إرجاع null.</li>
 * </ul>
 */
public final class ModernEngine {

    private static volatile XposedInterface XI;
    private static volatile boolean bootstrapped = false;

    private static final AtomicInteger HOOKS = new AtomicInteger(0);
    private static final Set<String> SEEN = new HashSet<String>();

    private static volatile boolean dataDone = false;
    private static volatile boolean spiesDone = false;

    public static void onPackageLoaded(
            XposedInterface xi,
            XposedModuleInterface.PackageLoadedParam lp) {
        if (xi == null || lp == null) return;
        XI = xi;

        String pkg;
        try {
            pkg = lp.getPackageName();
        } catch (Throwable t) {
            return;
        }
        // 0) لا نخترق أنفسنا.
        if (Config.MODULE_PACKAGE.equals(pkg)) return;
        // 1) حارس الإصدار (21+ بتسامح).
        int sdk = sdkInt();
        if (sdk < Config.MIN_SDK) return;
        // 2) أي حزمة (بغض النظر عن الاسم).
        if (!Config.TARGET_ALL_PACKAGES && !isHostHint(pkg)) return;

        try {
            Ctx.setPackageName(pkg);
            mlog(Log.INFO, Config.SHORT_DESC
                    + " | engine=modern"
                    + " | sdk=" + sdk
                    + " | pkg=" + pkg
                    + " | firstPkg=" + safeFirstPackage(lp));

            ClassLoader bootLoader = safeLoader(lp);
            if (bootLoader != null) {
                LoaderCollector.addExternal(bootLoader, false);
            }

            installSpiesOnce();
            startActivationChain();
        } catch (Throwable t) {
            mlog(Log.WARN, "modern bootstrap guard: " + t);
        }
    }

    // ================================================================
    // جواسيس اللوادر (مرة واحدة) — Application/Activity عبر الواجهة الحديثة
    // ================================================================
    private static void installSpiesOnce() {
        if (spiesDone) return;
        spiesDone = true;
        Safe.run("m-spies", new Safe.Block() {
            @Override public void run() throws Throwable {
                hookAfter("android.app.Application", "attachBaseContext",
                        new Class<?>[]{Context.class}, new After() {
                            @Override public Object run(Chain0 c) {
                                try {
                                    Context ctx = (Context) c.arg(0);
                                    Ctx.set(ctx);
                                    if (ctx != null) {
                                        LoaderCollector.addExternal(
                                                ctx.getClassLoader(), true);
                                    }
                                } catch (Throwable ignored) {}
                                return null;
                            }
                        });
                hookAfter("android.app.Application", "onCreate",
                        new Class<?>[0], new After() {
                            @Override public Object run(Chain0 c) {
                                try {
                                    Object app = c.thisObj();
                                    if (app instanceof Application) {
                                        Ctx.set((Application) app);
                                        LoaderCollector.addExternal(
                                                ((Application) app).getClassLoader(), true);
                                    }
                                } catch (Throwable ignored) {}
                                return null;
                            }
                        });
                hookAfter("android.app.Activity", "onCreate",
                        new Class<?>[]{Bundle.class}, new After() {
                            @Override public Object run(Chain0 c) {
                                try {
                                    Object a = c.thisObj();
                                    if (a instanceof Activity) {
                                        Ctx.set((Activity) a);
                                        LoaderCollector.addExternal(
                                                ((Activity) a).getClassLoader(), true);
                                    }
                                } catch (Throwable ignored) {}
                                return null;
                            }
                        });
            }
        });
    }

    // ================================================================
    // سلسلة التفعيل (نفس تأخيرات المسار القديم)
    // ================================================================
    private static void startActivationChain() {
        Safe.run("m-chain", new Safe.Block() {
            @Override public void run() throws Throwable {
                Thread t = new Thread(new Runnable() {
                    @Override public void run() {
                        long elapsed = 0L;
                        for (int i = 0; i < Config.ACTIVATION_DELAYS_MS.length; i++) {
                            long waitFor = Config.ACTIVATION_DELAYS_MS[i] - elapsed;
                            if (waitFor > 0) {
                                try {
                                    Thread.sleep(waitFor);
                                } catch (InterruptedException e) {
                                    Thread.currentThread().interrupt();
                                    return;
                                }
                                elapsed = Config.ACTIVATION_DELAYS_MS[i];
                            }
                            if (killSwitchOn()) {
                                mlog(Log.WARN, "kill-switch ON — activation halted safely");
                                return;
                            }
                            final int pass = i + 1;
                            Safe.run("m-pass-" + pass, new Safe.Block() {
                                @Override public void run() throws Throwable {
                                    mlog(Log.INFO, "activation pass " + pass
                                            + "/" + Config.ACTIVATION_DELAYS_MS.length
                                            + " (modern)");
                                    activate(Ctx.get());
                                }
                            });
                        }
                    }
                }, "LokTvHookPro-Modern");
                t.setDaemon(true);
                t.start();
            }
        });
    }

    static void activate(Context ctx) {
        loadFlags();
        hookDataLayersOnce();
        if (FeatureFlags.nativeLog) {
            final File apk = apkOf(Ctx.get() != null ? Ctx.get() : ctx);
            Safe.run("m-native", new Safe.Block() {
                @Override public void run() throws Throwable {
                    NativeScan.report(apk);
                    hookNativeSpies();
                }
            });
        }

        final Set<String> names = new HashSet<String>();
        Safe.run("m-dexNames", new Safe.Block() {
            @Override public void run() throws Throwable {
                File apk = apkOf(Ctx.get());
                if (apk != null) {
                    names.addAll(DexNames.collect(apk));
                    mlog(Log.INFO, "inventory: " + apk + " names=" + names.size());
                }
            }
        });

        Set<String> candidates = new HashSet<String>();
        for (String n : names) {
            if (n == null || n.isEmpty()) continue;
            if (Config.isInfrastructure(n)) continue;
            String lower = n.toLowerCase(Locale.US);
            if (Config.isVipName(lower) || Config.isDetectName(lower)) candidates.add(n);
            if (candidates.size() > Config.MAX_CLASSES_SCAN) break;
        }
        mlog(Log.INFO, "scan: names=" + names.size()
                + " candidates=" + candidates.size());

        long t0 = System.currentTimeMillis();
        for (ClassLoader cl : LoaderCollector.all()) {
            if (!LoaderCollector.tryArm(cl)) continue;
            for (String name : candidates) {
                if (System.currentTimeMillis() - t0 > Config.SCAN_TIME_BUDGET_MS) {
                    mlog(Log.WARN, "scan budget exceeded");
                    break;
                }
                hookClassByName(name, cl);
            }
        }

        mlog(Log.INFO, "SUMMARY hooks=" + HOOKS.get()
                + " classes=" + classCount()
                + " targeted=" + targetedCount()
                + " activated=true engine=modern"
                + " features=vip-gate/tier/expiry/fields/prefs-json-text-bundle+native-log"
                + " | LokTvHookPro v" + Config.VERSION_NAME);
    }

    // ================================================================
    // ربط صنف بالبصمة (مسار حديث)
    // ================================================================
    private static void hookClassByName(String name, ClassLoader cl) {
        if (name == null || cl == null) return;
        Class<?> k;
        try {
            k = Class.forName(name, false, cl);
        } catch (Throwable t) {
            return;
        }
        if (k.isInterface() || Modifier.isAbstract(k.getModifiers())) return;

        int tier = HookEngine.classify(name.toLowerCase(Locale.US));
        if (tier == 2 && !FeatureFlags.detect) return;
        if (tier == 1 && !FeatureFlags.vip) return;
        if (tier == 0) return;

        int added = 0;
        int perClass = 0;
        List<Method> methods = Reflect.allMethods(k);
        for (int i = 0; i < methods.size(); i++) {
            final Method m = methods.get(i);
            if (perClass >= Config.MAX_HOOKS_PER_CLASS) break;
            if (HOOKS.get() >= Config.MAX_HOOKS) return;
            if (!modernCanHook(m)) continue;
            final int fTier = tier;
            try {
                hookExec(m, new XposedInterface.Hooker() {
                    @Override public Object intercept(XposedInterface.Chain chain) {
                        try {
                            return dispatch(m, chain, fTier);
                        } catch (Throwable t) {
                            mlog(Log.WARN, "modern dispatch guard: " + t);
                            try {
                                return chain.proceed();
                            } catch (Throwable t2) {
                                return null;
                            }
                        }
                    }
                });
                added++;
                perClass++;
                HOOKS.incrementAndGet();
            } catch (Throwable ignored) {}
        }
        if (added > 0) {
            mlog(Log.INFO, "hooked class: " + name + " hooks+=" + added);
        }
    }

    private static boolean modernCanHook(Method m) {
        if (m == null) return false;
        int mod = m.getModifiers();
        if (Modifier.isAbstract(mod)) return false;
        if (Modifier.isNative(mod)) return false;
        if (Config.isProtectedMethodName(m.getName())) return false;
        String sig;
        try {
            sig = m.getDeclaringClass().getName() + "#" + m.getName()
                    + java.util.Arrays.toString(m.getParameterTypes());
        } catch (Throwable t) {
            return false;
        }
        synchronized (SEEN) {
            return SEEN.add(sig);
        }
    }

    /** قرار الإرجاع — مرآة HookEngine.buildHandler بميكانيكا Chain. */
    private static Object dispatch(Method m, XposedInterface.Chain chain, int tier)
            throws Throwable {
        Class<?> rt = m.getReturnType();
        String mnl = m.getName().toLowerCase(Locale.US);

        if (tier == 2) {
            if (rt == boolean.class) return false;
            if (rt == int.class || rt == long.class) {
                return Safe.coerceReturn(m, 0L);
            }
            if (mnl.contains("call") || mnl.contains("check") || mnl.contains("detect")) {
                if (rt == void.class) {
                    chain.proceed();
                    return null;
                }
                if (rt == boolean.class) return false;
                if (rt == int.class) return 0;
                if (rt == long.class) return 0L;
                // إرجاع كائن مجهول: مراقبة فقط (أسلم من null)
                return chain.proceed();
            }
            return chain.proceed();
        }

        if (rt == boolean.class) return true;
        if (rt == int.class || rt == long.class) {
            long v = HookEngine.isExpiryMethod(mnl)
                    ? Config.VALUE_LONG_EXPIRE : Config.VALUE_LONG_DEFAULT;
            return Safe.coerceReturn(m, v);
        }
        if (rt == String.class && HookEngine.isVipMethodName(mnl)) {
            return Config.VALUE_STRING_VIP;
        }
        if (rt == void.class && HookEngine.isVipMethodName(mnl)) {
            chain.proceed();
            forceBooleans(chain.getThisObject());
            return null;
        }
        return chain.proceed();
    }

    private static void forceBooleans(Object self) {
        if (self == null) return;
        try {
            Class<?> k = self.getClass();
            while (k != null && k != Object.class) {
                java.lang.reflect.Field[] fields;
                try {
                    fields = k.getDeclaredFields();
                } catch (Throwable t) {
                    break;
                }
                for (int i = 0; i < fields.length; i++) {
                    final java.lang.reflect.Field f = fields[i];
                    if (Modifier.isStatic(f.getModifiers())) continue;
                    if (f.getType() != boolean.class) continue;
                    try {
                        f.setAccessible(true);
                        f.setBoolean(self, true);
                    } catch (Throwable ignored) {}
                }
                k = k.getSuperclass();
            }
        } catch (Throwable t) {
            mlog(Log.WARN, "forceBooleans: " + t);
        }
    }

    // ================================================================
    // طبقات البيانات (مرة واحدة)
    // ================================================================
    private static void hookDataLayersOnce() {
        if (dataDone) return;
        dataDone = true;
        if (FeatureFlags.prefs) {
            Safe.run("m-prefs", new Safe.Block() {
                @Override public void run() throws Throwable { hookPrefs(); }
            });
        }
        if (FeatureFlags.json) {
            Safe.run("m-json", new Safe.Block() {
                @Override public void run() throws Throwable { hookJson(); }
            });
        }
        if (FeatureFlags.text) {
            Safe.run("m-text", new Safe.Block() {
                @Override public void run() throws Throwable { hookText(); }
            });
        }
        if (FeatureFlags.bundle) {
            Safe.run("m-bundle", new Safe.Block() {
                @Override public void run() throws Throwable { hookBundleIntent(); }
            });
        }
    }

    private static void hookPrefs() {
        Class<?> impl = frameworkClass("android.app.SharedPreferencesImpl");
        if (impl == null) {
            mlog(Log.WARN, "prefs: SharedPreferencesImpl not found, skipping");
            return;
        }
        hookKeyed(impl, "getBoolean", new Class<?>[]{String.class, boolean.class},
                new Forced() {
                    @Override public Object value(String norm) {
                        return Config.isVipKey(norm) ? Boolean.TRUE : null;
                    }
                });
        hookKeyed(impl, "getInt", new Class<?>[]{String.class, int.class},
                new Forced() {
                    @Override public Object value(String norm) {
                        if (!Config.isVipKey(norm)) return null;
                        return Config.isExpiryName(norm) ? 2100 : 99;
                    }
                });
        hookKeyed(impl, "getLong", new Class<?>[]{String.class, long.class},
                new Forced() {
                    @Override public Object value(String norm) {
                        if (!Config.isVipKey(norm)) return null;
                        return Config.isExpiryName(norm)
                                ? Config.VALUE_LONG_EXPIRE : Config.VALUE_LONG_DEFAULT;
                    }
                });
        hookKeyed(impl, "getString", new Class<?>[]{String.class, String.class},
                new Forced() {
                    @Override public Object value(String norm) {
                        return Config.isVipKey(norm) ? Config.VALUE_STRING_VIP : null;
                    }
                });
        hookKeyed(impl, "contains", new Class<?>[]{String.class},
                new Forced() {
                    @Override public Object value(String norm) {
                        return Config.isVipKey(norm) ? Boolean.TRUE : null;
                    }
                });
        mlog(Log.INFO, "data-layer: SharedPreferencesImpl hooked (modern)");
    }

    private static void hookJson() {
        final Class<?> c = JSONObject.class;
        String[] names = {"getBoolean", "optBoolean", "getInt", "optInt",
                "getLong", "optLong", "getString", "optString"};
        for (int i = 0; i < names.length; i++) {
            final String mName = names[i];
            Safe.run("m-json." + mName, new Safe.Block() {
                @Override public void run() throws Throwable {
                    for (Method mm : c.getDeclaredMethods()) {
                        if (!mm.getName().equals(mName)) continue;
                        if (mm.getParameterTypes().length != 1) continue;
                        if (mm.getParameterTypes()[0] != String.class) continue;
                        final Method target = mm;
                        hookExec(target, new XposedInterface.Hooker() {
                            @Override public Object intercept(XposedInterface.Chain chain) {
                                try {
                                    String key = (String) chain.getArg(0);
                                    String norm = normKey(key);
                                    if (norm == null || !Config.isVipKey(norm)) {
                                        return chain.proceed();
                                    }
                                    Class<?> rt = target.getReturnType();
                                    if (rt == boolean.class) return true;
                                    if (rt == int.class) {
                                        return Config.isExpiryName(norm) ? 2100 : 99;
                                    }
                                    if (rt == long.class) {
                                        return Config.isExpiryName(norm)
                                                ? Config.VALUE_LONG_EXPIRE
                                                : Config.VALUE_LONG_DEFAULT;
                                    }
                                    if (rt == String.class) return Config.VALUE_STRING_VIP;
                                    return chain.proceed();
                                } catch (Throwable t) {
                                    return proceedQuiet(chain);
                                }
                            }
                        });
                    }
                }
            });
        }
        mlog(Log.INFO, "data-layer: org.json.JSONObject hooked (modern)");
    }

    private static void hookText() {
        try {
            Method setText = null;
            for (Method mm : TextView.class.getDeclaredMethods()) {
                if (!mm.getName().equals("setText")) continue;
                if (mm.getParameterTypes().length != 1) continue;
                if (mm.getParameterTypes()[0] != CharSequence.class) continue;
                setText = mm;
                break;
            }
            if (setText == null) return;
            hookExec(setText, new XposedInterface.Hooker() {
                @Override public Object intercept(XposedInterface.Chain chain) {
                    try {
                        Object arg = chain.getArg(0);
                        if (arg instanceof CharSequence) {
                            String s = arg.toString();
                            for (int i = 0; i < Config.TEXT_REPLACEMENTS.length; i++) {
                                String[] rule = Config.TEXT_REPLACEMENTS[i];
                                if (rule.length == 2 && rule[0].equals(s)) {
                                    return chain.proceed(new Object[]{rule[1]});
                                }
                            }
                        }
                        return chain.proceed();
                    } catch (Throwable t) {
                        return proceedQuiet(chain);
                    }
                }
            });
            mlog(Log.INFO, "text-layer: TextView.setText hooked (modern)");
        } catch (Throwable t) {
            mlog(Log.WARN, "text hook: " + t);
        }
    }

    private static void hookBundleIntent() {
        Class<?> bundle = frameworkClass("android.os.Bundle");
        Class<?> intent = frameworkClass("android.content.Intent");
        if (bundle != null) {
            hookKeyed(bundle, "getBoolean", new Class<?>[]{String.class},
                    vipBool());
            hookKeyed(bundle, "getBoolean", new Class<?>[]{String.class, boolean.class},
                    vipBool());
            hookKeyed(bundle, "getInt", new Class<?>[]{String.class}, vipInt99());
            hookKeyed(bundle, "getInt", new Class<?>[]{String.class, int.class}, vipInt99());
            hookKeyed(bundle, "containsKey", new Class<?>[]{String.class}, vipBool());
        }
        if (intent != null) {
            hookKeyed(intent, "getBooleanExtra",
                    new Class<?>[]{String.class, boolean.class}, vipBool());
            hookKeyed(intent, "getIntExtra",
                    new Class<?>[]{String.class, int.class}, vipInt99());
            hookKeyed(intent, "hasExtra", new Class<?>[]{String.class}, vipBool());
        }
        mlog(Log.INFO, "data-layer: Bundle/Intent extras hooked (modern)");
    }

    private static void hookNativeSpies() {
        hookObserve(System.class, "loadLibrary", new Class<?>[]{String.class});
        hookObserve(System.class, "load", new Class<?>[]{String.class});
        mlog(Log.INFO, "native: load spies installed (modern, observe-only)");
    }

    // ================================================================
    // بدائيات حديثة صغيرة
    // ================================================================
    private interface Forced {
        /** قيمة مفروضة، أو null لتمرير الأصل. */
        Object value(String normKey);
    }

    private interface After {
        Object run(Chain0 c);
    }

    /** غلاف Chain لتقصير الكود. */
    private static class Chain0 {
        final XposedInterface.Chain chain;
        Chain0(XposedInterface.Chain chain) { this.chain = chain; }
        Object arg(int i) {
            try { return chain.getArg(i); } catch (Throwable t) { return null; }
        }
        Object thisObj() {
            try { return chain.getThisObject(); } catch (Throwable t) { return null; }
        }
    }

    /** هوك framework method بالاسم — يُحَل عبر boot (أصناف الإطار دائماً حاضرة). */
    private static void hookAfter(String cls, String name, Class<?>[] params, final After after) {
        try {
            Class<?> c = Class.forName(cls);
            final Method m = c.getDeclaredMethod(name, params);
            hookExec(m, new XposedInterface.Hooker() {
                @Override public Object intercept(XposedInterface.Chain chain) {
                    Object r;
                    try {
                        r = chain.proceed();
                    } catch (Throwable t) {
                        return null;
                    }
                    try {
                        after.run(new Chain0(chain));
                    } catch (Throwable ignored) {}
                    return r;
                }
            });
        } catch (Throwable t) {
            mlog(Log.WARN, "hookAfter " + cls + "#" + name + ": " + t);
        }
    }

    /** إجبار قيمة حسب المفتاح (طبقات البيانات). */
    private static void hookKeyed(Class<?> cls, String name, Class<?>[] params,
                                 final Forced forced) {
        Method m;
        try {
            m = cls.getDeclaredMethod(name, params);
        } catch (Throwable t) {
            return;
        }
        hookExec(m, new XposedInterface.Hooker() {
            @Override public Object intercept(XposedInterface.Chain chain) {
                try {
                    String key = (String) chain.getArg(0);
                    String norm = normKey(key);
                    if (norm == null) return chain.proceed();
                    if (Config.isAnalyticsKey(norm)) return chain.proceed();
                    Object v = forced.value(norm);
                    if (v == null) return chain.proceed();
                    return v;
                } catch (Throwable t) {
                    return proceedQuiet(chain);
                }
            }
        });
    }

    private static void hookObserve(Class<?> cls, String name, Class<?>[] params) {
        Method m;
        try {
            m = cls.getDeclaredMethod(name, params);
        } catch (Throwable t) {
            return;
        }
        hookExec(m, new XposedInterface.Hooker() {
            @Override public Object intercept(XposedInterface.Chain chain) {
                Object r;
                try {
                    r = chain.proceed();
                } catch (Throwable t) {
                    return null;
                }
                try {
                    mlog(Log.DEBUG, "native load: " + chain.getArg(0));
                } catch (Throwable ignored) {}
                return r;
            }
        });
    }

    private static void hookExec(java.lang.reflect.Executable m, XposedInterface.Hooker h) {
        XposedInterface xi = XI;
        if (xi == null || m == null || h == null) return;
        try {
            xi.hook(m)
                    .setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                    .intercept(h);
        } catch (Throwable t) {
            mlog(Log.WARN, "hookExec " + m + ": " + t);
        }
    }

    private static Forced vipBool() {
        return new Forced() {
            @Override public Object value(String norm) {
                return Config.isVipKey(norm) ? Boolean.TRUE : null;
            }
        };
    }

    private static Forced vipInt99() {
        return new Forced() {
            @Override public Object value(String norm) {
                if (!Config.isVipKey(norm)) return null;
                return Config.isExpiryName(norm) ? 2100 : 99;
            }
        };
    }

    private static Object proceedQuiet(XposedInterface.Chain chain) {
        try {
            return chain.proceed();
        } catch (Throwable t) {
            return null;
        }
    }

    // ================================================================
    // أدوات
    // ================================================================
    private static void loadFlags() {
        Safe.run("m-flags", new Safe.Block() {
            @Override public void run() throws Throwable {
                SharedPreferences sp = null;
                try {
                    if (XI != null) {
                        sp = XI.getRemotePreferences(FeatureFlags.PREFS_NAME);
                    }
                } catch (Throwable ignored) {
                    sp = null;
                }
                FeatureFlags.loadModern(sp);
            }
        });
    }

    private static Class<?> frameworkClass(String name) {
        try {
            return Class.forName(name);
        } catch (Throwable t) {
            return null;
        }
    }

    private static String normKey(String key) {
        if (key == null) return null;
        try {
            return key.toLowerCase(Locale.US).replace("_", "");
        } catch (Throwable t) {
            return null;
        }
    }

    private static File apkOf(Context ctx) {
        if (ctx == null) return null;
        try {
            String p = ctx.getPackageCodePath();
            if (p == null) return null;
            File f = new File(p);
            return f.isFile() ? f : null;
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean killSwitchOn() {
        try {
            Context ctx = Ctx.get();
            if (ctx == null) return false;
            File dir = null;
            try { dir = ctx.getCacheDir(); } catch (Throwable ignored) {}
            if (dir == null) return false;
            return new File(dir, Config.KILLSWITCH_FILE).exists();
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean isHostHint(String pkg) {
        if (pkg == null) return false;
        String p = pkg.toLowerCase();
        for (int i = 0; i < Config.HOST_PKG_HINTS.length; i++) {
            if (p.startsWith(Config.HOST_PKG_HINTS[i])) return true;
        }
        return false;
    }

    private static int sdkInt() {
        try {
            return android.os.Build.VERSION.SDK_INT;
        } catch (Throwable t) {
            return Config.MIN_SDK;
        }
    }

    private static ClassLoader safeLoader(XposedModuleInterface.PackageLoadedParam lp) {
        try {
            return lp.getDefaultClassLoader();
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean safeFirstPackage(XposedModuleInterface.PackageLoadedParam lp) {
        try {
            return lp.isFirstPackage();
        } catch (Throwable t) {
            return true;
        }
    }

    private static int classCount() {
        synchronized (SEEN) {
            return SEEN.size();
        }
    }

    private static int targetedCount() {
        return classCount();
    }

    static void mlog(int prio, String msg) {
        try {
            if (XI != null) {
                XI.log(prio, "LokTvHookPro", msg);
                return;
            }
        } catch (Throwable ignored) {}
        XLog.i(msg);
    }

    private ModernEngine() {}
}
