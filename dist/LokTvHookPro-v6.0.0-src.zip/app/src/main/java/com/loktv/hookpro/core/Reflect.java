package com.loktv.hookpro.core;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** انعكاس آمن عبر الوراثة (superclass walk) — لا أسماء ثابتة وحيدة. */
public final class Reflect {

    public static Field field(Class<?> c, String name) {
        Class<?> cur = c;
        while (cur != null) {
            try {
                Field f = cur.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (Throwable ignored) {}
            cur = cur.getSuperclass();
        }
        return null;
    }

    public static Object get(Object obj, Field f) {
        if (f == null) return null;
        try { return f.get(obj); } catch (Throwable t) { return null; }
    }

    public static void set(Object obj, Field f, Object v) {
        if (f == null) return;
        try { f.set(obj, v); } catch (Throwable ignored) {}
    }

    public static Method method(Class<?> c, String name, Class<?>... params) {
        Class<?> cur = c;
        while (cur != null) {
            try {
                Method m = cur.getDeclaredMethod(name, params);
                m.setAccessible(true);
                return m;
            } catch (Throwable ignored) {}
            cur = cur.getSuperclass();
        }
        return null;
    }

    public static Object call(Method m, Object target, Object... args) {
        if (m == null) return null;
        try { return m.invoke(target, args); } catch (Throwable t) { return null; }
    }

    /** كل الدوال المعلنة على الصنف وأسلافه (بلا تكرار) — تلتقط دوال VIP الموروثة. */
    public static List<Method> allMethods(Class<?> clazz) {
        List<Method> out = new ArrayList<Method>();
        Set<String> seen = new HashSet<String>();
        Class<?> c = clazz;
        while (c != null && c != Object.class) {
            Method[] declared;
            try {
                declared = c.getDeclaredMethods();
            } catch (Throwable t) {
                break;
            }
            for (int i = 0; i < declared.length; i++) {
                Method m = declared[i];
                String key = m.getName() + "#" + Arrays.toString(m.getParameterTypes());
                if (seen.add(key)) {
                    try {
                        m.setAccessible(true);
                    } catch (Throwable ignored) {}
                    out.add(m);
                }
            }
            c = c.getSuperclass();
        }
        return out;
    }

    private Reflect() {}
}
