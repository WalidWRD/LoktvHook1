package com.loktv.hookpro.core;

import java.lang.reflect.Method;

/** كل تنفيذ محمي: أي استثناء يُسجَّل فقط ولا يكسر التطبيق الهدف أبداً. */
public final class Safe {

    public interface Block { void run() throws Throwable; }
    public interface Call<T> { T run() throws Throwable; }

    public static void run(String tag, Block b) {
        try { b.run(); }
        catch (Throwable t) { XLog.w(tag + " failed: " + t); }
    }

    public static <T> T call(String tag, Call<T> c, T fallback) {
        try { return c.run(); }
        catch (Throwable t) { XLog.w(tag + " failed: " + t); return fallback; }
    }

    /**
     * تكييف قيمة الإرجاع لنوع الدالة المعلن — يمنع ClassCastException
     * (مثلاً Long على دالة int) عند فرض القيم في الهوكات.
     */
    public static Object coerceReturn(Method m, Object value) {
        if (m == null) return value;
        Class<?> rt = m.getReturnType();
        if (rt == void.class) return null;

        if (value == null) {
            if (rt == int.class)     return 0;
            if (rt == long.class)    return 0L;
            if (rt == short.class)   return (short) 0;
            if (rt == byte.class)    return (byte) 0;
            if (rt == boolean.class) return Boolean.FALSE;
            if (rt == float.class)   return 0f;
            if (rt == double.class)  return 0d;
            if (rt == char.class)    return (char) 0;
            return null;
        }

        Number n;
        if (value instanceof Number) {
            n = (Number) value;
        } else if (value instanceof Boolean) {
            n = ((Boolean) value) ? 1 : 0;
        } else {
            try {
                n = Long.parseLong(value.toString());
            } catch (Throwable t) {
                n = 0L;
            }
        }

        if (rt == int.class     || rt == Integer.class) return n.intValue();
        if (rt == long.class    || rt == Long.class)    return n.longValue();
        if (rt == short.class   || rt == Short.class)   return n.shortValue();
        if (rt == byte.class    || rt == Byte.class)    return n.byteValue();
        if (rt == float.class   || rt == Float.class)   return n.floatValue();
        if (rt == double.class  || rt == Double.class)  return n.doubleValue();
        if (rt == boolean.class || rt == Boolean.class) return n.intValue() != 0;
        if (rt == char.class    || rt == Character.class) return (char) n.intValue();
        return value;
    }

    private Safe() {}
}
