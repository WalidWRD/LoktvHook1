package com.loktv.hookpro.core;

import android.content.Context;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * محرك الربط: بصمة اسم الصنف + بصمة التوقيع (نوع الإرجاع) — لا أسماء ثابتة.
 * كل الطبقات محمية بـ Safe ولا تُطبَّق طبقات البيانات إلا مرة واحدة.
 */
public final class UnlockEngine {

    /** محرك ربط الأصناف — نفس السياسة، مع coerceReturn وجرد الوراثة. */
    private static final HookEngine ENGINE = new HookEngine();

    private static volatile boolean prefsHooked = false;
    private static volatile boolean jsonHooked = false;
    private static volatile boolean textHooked = false;
    private static volatile boolean bundleHooked = false;

    public static void activate(Context ctx) {
        XLog.i("=== activate | ctx=" + (ctx != null) + " ===");
        FeatureFlags.load();

        // 1) اربط الطبقات الحرجة أولاً (مرة واحدة فقط، وحسب مفاتيح الميزات)
        if (FeatureFlags.prefs) {
            Safe.run("prefs", new Safe.Block() {
                @Override public void run() throws Throwable { hookSharedPreferences(); }
            });
        }
        if (FeatureFlags.json) {
            Safe.run("json", new Safe.Block() {
                @Override public void run() throws Throwable { hookJson(); }
            });
        }
        if (FeatureFlags.text) {
            Safe.run("text", new Safe.Block() {
                @Override public void run() throws Throwable { hookTextView(); }
            });
        }
        if (FeatureFlags.bundle) {
            Safe.run("bundle", new Safe.Block() {
                @Override public void run() throws Throwable { hookBundleIntent(); }
            });
        }
        if (FeatureFlags.nativeLog) {
            final Context fCtx = (Ctx.get() != null) ? Ctx.get() : ctx;
            Safe.run("native", new Safe.Block() {
                @Override public void run() throws Throwable {
                    NativeScan.report(apkOf(fCtx));
                    NativeScan.installLoadSpies();
                }
            });
        }

        // 2) اجرد أصناف المضيف من جدول DEX
        final Set<String> names = new HashSet<String>();
        Safe.run("dexNames", new Safe.Block() {
            @Override public void run() throws Throwable {
                File apk = apkOf(Ctx.get() != null ? Ctx.get() : ctx);
                if (apk != null) {
                    names.addAll(DexNames.collect(apk));
                    XLog.i("inventory: " + apk + " names=" + names.size());
                }
            }
        });

        // 3) فلترة الأصناف المرشّحة بالبصمة
        Set<String> candidates = new HashSet<String>();
        for (String n : names) {
            if (n == null || n.isEmpty()) continue;
            if (Config.isInfrastructure(n)) continue;
            String lower = n.toLowerCase(Locale.US);
            if (Config.isVipName(lower) || Config.isDetectName(lower)) candidates.add(n);
            if (candidates.size() > Config.MAX_CLASSES_SCAN) break;
        }
        XLog.i("scan: names=" + names.size() + " candidates=" + candidates.size());

        // 4) ربط كل مرشّح بدرجته (بحد زمني حتى لا يعلّق بدء التطبيق)
        //    tryArm: كل loader يُسلَّح مرة واحدة — يمنع re-arm عبر التمريرات
        long t0 = System.currentTimeMillis();
        for (ClassLoader cl : LoaderCollector.all()) {
            if (!LoaderCollector.tryArm(cl)) continue;
            for (String name : candidates) {
                if (System.currentTimeMillis() - t0 > Config.SCAN_TIME_BUDGET_MS) {
                    XLog.w("scan budget exceeded");
                    break;
                }
                final String fName = name;
                final ClassLoader fCl = cl;
                Safe.run("hook:" + fName, new Safe.Block() {
                    @Override public void run() throws Throwable { hookClass(fName, fCl); }
                });
            }
        }

        XLog.i("SUMMARY hooks=" + ENGINE.hookCount()
                + " classes=" + ENGINE.classCount()
                + " targeted=" + ENGINE.targeted()
                + " activated=true"
                + " features=vip-gate/tier/expiry/fields/prefs-json-text-bundle+native-log"
                + " | LokTvHookPro v" + Config.VERSION_NAME);
    }

    // ================================================================
    // طبقة SharedPreferences (مرة واحدة)
    // ================================================================
    private static void hookSharedPreferences() {
        if (prefsHooked) return;
        prefsHooked = true;

        // SharedPreferencesImpl صنف إطار: جرّب boot أولاً ثم أي loader متاح
        Class<?> impl = null;
        try {
            impl = Class.forName("android.app.SharedPreferencesImpl", false, null);
        } catch (Throwable ignored) {}
        if (impl == null) {
            for (ClassLoader cl : LoaderCollector.all()) {
                try {
                    impl = Class.forName("android.app.SharedPreferencesImpl", false, cl);
                    if (impl != null) break;
                } catch (Throwable ignored) {}
            }
        }
        if (impl == null) {
            XLog.w("prefs: SharedPreferencesImpl not found, skipping");
            return;
        }
        final Class<?> target = impl;

        hookBooleanGetter(target, "getBoolean", true);
        hookIntGetter(target, "getInt", 99);
        try {
            XposedHelpers.findAndHookMethod(target, "contains", String.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        String k = (String) p.args[0];
                        if (k == null) return;
                        String norm = k.toLowerCase(Locale.US).replace("_", "");
                        if (Config.isVipKey(norm)) p.setResult(true);
                    } catch (Throwable t) {
                        XLog.w("prefs.contains: " + t);
                    }
                }
            });
        } catch (Throwable t) {
            XLog.w("prefs.contains hook: " + t);
        }
        XLog.i("data-layer: SharedPreferencesImpl hooked");
    }

    private static void hookBooleanGetter(Class<?> target, String m, final boolean forced) {
        try {
            XposedHelpers.findAndHookMethod(target, m, String.class, boolean.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        String k = (String) p.args[0];
                        if (k == null) return;
                        String norm = k.toLowerCase(Locale.US).replace("_", "");
                        if (Config.isAnalyticsKey(norm)) return;
                        if (Config.isVipKey(norm)) p.setResult(forced);
                    } catch (Throwable t) {
                        XLog.w("prefs." + m + ": " + t);
                    }
                }
            });
        } catch (Throwable t) {
            XLog.w("prefs." + m + " hook: " + t);
        }
    }

    private static void hookIntGetter(Class<?> target, String m, final int forced) {
        try {
            XposedHelpers.findAndHookMethod(target, m, String.class, int.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        String k = (String) p.args[0];
                        if (k == null) return;
                        String norm = k.toLowerCase(Locale.US).replace("_", "");
                        if (Config.isAnalyticsKey(norm)) return;
                        if (Config.isVipKey(norm)) {
                            p.setResult(Config.isExpiryName(norm)
                                    ? 2100 : forced);
                        }
                    } catch (Throwable t) {
                        XLog.w("prefs." + m + ": " + t);
                    }
                }
            });
        } catch (Throwable t) {
            XLog.w("prefs." + m + " hook: " + t);
        }
    }

    // ================================================================
    // طبقة JSONObject (مرة واحدة)
    // ================================================================
    private static void hookJson() {
        if (jsonHooked) return;
        jsonHooked = true;

        final Class<?> c = JSONObject.class;
        String[] boolMethods = {"getBoolean", "optBoolean"};
        String[] intMethods = {"getInt", "optInt"};
        for (int i = 0; i < boolMethods.length; i++) {
            final String m = boolMethods[i];
            Safe.run("json." + m, new Safe.Block() {
                @Override public void run() throws Throwable {
                    for (Method mm : c.getDeclaredMethods()) {
                        if (!mm.getName().equals(m)) continue;
                        if (mm.getParameterTypes().length < 1) continue;
                        if (mm.getParameterTypes()[0] != String.class) continue;
                        final Method target = mm;
                        XposedBridge.hookMethod(target, new XC_MethodHook() {
                            @Override protected void beforeHookedMethod(MethodHookParam p) {
                                try {
                                    String k = (String) p.args[0];
                                    if (k == null) return;
                                    String norm = k.toLowerCase(Locale.US).replace("_", "");
                                    if (Config.isVipKey(norm)) {
                                        if (target.getReturnType() == boolean.class) {
                                            p.setResult(true);
                                        } else if (target.getReturnType() == int.class) {
                                            p.setResult(Config.isExpiryName(norm) ? 2100 : 99);
                                        }
                                    }
                                } catch (Throwable t) {
                                    XLog.w("json." + m + ": " + t);
                                }
                            }
                        });
                    }
                }
            });
        }
        for (int i = 0; i < intMethods.length; i++) {
            final String m = intMethods[i];
            Safe.run("json.int." + m, new Safe.Block() {
                @Override public void run() throws Throwable {
                    for (Method mm : c.getDeclaredMethods()) {
                        if (!mm.getName().equals(m)) continue;
                        if (mm.getParameterTypes().length < 1) continue;
                        if (mm.getParameterTypes()[0] != String.class) continue;
                        XposedBridge.hookMethod(mm, new XC_MethodHook() {
                            @Override protected void beforeHookedMethod(MethodHookParam p) {
                                try {
                                    String k = (String) p.args[0];
                                    if (k == null) return;
                                    String norm = k.toLowerCase(Locale.US).replace("_", "");
                                    if (Config.isVipKey(norm)) {
                                        p.setResult(Config.isExpiryName(norm) ? 2100 : 99);
                                    }
                                } catch (Throwable t) {
                                    XLog.w("json." + m + ": " + t);
                                }
                            }
                        });
                    }
                }
            });
        }
        XLog.i("data-layer: org.json.JSONObject hooked");
    }

    // ================================================================
    // طبقة TextView (مرة واحدة)
    // ================================================================
    private static void hookTextView() {
        if (textHooked) return;
        textHooked = true;

        try {
            XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        Object arg = p.args[0];
                        if (!(arg instanceof CharSequence)) return;
                        String s = arg.toString();
                        for (int i = 0; i < Config.TEXT_REPLACEMENTS.length; i++) {
                            String[] rule = Config.TEXT_REPLACEMENTS[i];
                            if (s.equals(rule[0])) { p.args[0] = rule[1]; return; }
                        }
                    } catch (Throwable t) {
                        XLog.w("textview: " + t);
                    }
                }
            });
            XLog.i("text-layer: TextView.setText hooked ("
                    + Config.TEXT_REPLACEMENTS.length + " rules)");
        } catch (Throwable t) {
            XLog.w("textview hook: " + t);
        }
    }

    // ================================================================
    // طبقة Bundle / Intent extras (مرة واحدة) — أعلام VIP الممررة عبر النوايا
    // ================================================================
    private static void hookBundleIntent() {
        if (bundleHooked) return;
        bundleHooked = true;

        // --- android.os.Bundle ---
        Safe.run("bundle.bool", new Safe.Block() {
            @Override public void run() throws Throwable {
                XposedHelpers.findAndHookMethod(android.os.Bundle.class,
                        "getBoolean", String.class, new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (isVipExtra((String) p.args[0])) {
                            try { p.setResult(true); }
                            catch (Throwable t) { XLog.w("bundle.getBoolean: " + t); }
                        }
                    }
                });
                XposedHelpers.findAndHookMethod(android.os.Bundle.class,
                        "getBoolean", String.class, boolean.class, new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (isVipExtra((String) p.args[0])) {
                            try { p.setResult(true); }
                            catch (Throwable t) { XLog.w("bundle.getBoolean2: " + t); }
                        }
                    }
                });
            }
        });
        Safe.run("bundle.int", new Safe.Block() {
            @Override public void run() throws Throwable {
                XposedHelpers.findAndHookMethod(android.os.Bundle.class,
                        "getInt", String.class, new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (isVipExtra((String) p.args[0])) {
                            try { p.setResult(99); }
                            catch (Throwable t) { XLog.w("bundle.getInt: " + t); }
                        }
                    }
                });
                XposedHelpers.findAndHookMethod(android.os.Bundle.class,
                        "getInt", String.class, int.class, new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (isVipExtra((String) p.args[0])) {
                            try { p.setResult(99); }
                            catch (Throwable t) { XLog.w("bundle.getInt2: " + t); }
                        }
                    }
                });
            }
        });
        Safe.run("bundle.keys", new Safe.Block() {
            @Override public void run() throws Throwable {
                XposedHelpers.findAndHookMethod(android.os.Bundle.class,
                        "containsKey", String.class, new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (isVipExtra((String) p.args[0])) {
                            try { p.setResult(true); }
                            catch (Throwable t) { XLog.w("bundle.containsKey: " + t); }
                        }
                    }
                });
            }
        });

        // --- android.content.Intent ---
        Safe.run("intent.bool", new Safe.Block() {
            @Override public void run() throws Throwable {
                XposedHelpers.findAndHookMethod(android.content.Intent.class,
                        "getBooleanExtra", String.class, boolean.class,
                        new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (isVipExtra((String) p.args[0])) {
                            try { p.setResult(true); }
                            catch (Throwable t) { XLog.w("intent.getBooleanExtra: " + t); }
                        }
                    }
                });
            }
        });
        Safe.run("intent.int", new Safe.Block() {
            @Override public void run() throws Throwable {
                XposedHelpers.findAndHookMethod(android.content.Intent.class,
                        "getIntExtra", String.class, int.class, new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (isVipExtra((String) p.args[0])) {
                            try { p.setResult(99); }
                            catch (Throwable t) { XLog.w("intent.getIntExtra: " + t); }
                        }
                    }
                });
            }
        });
        Safe.run("intent.has", new Safe.Block() {
            @Override public void run() throws Throwable {
                XposedHelpers.findAndHookMethod(android.content.Intent.class,
                        "hasExtra", String.class, new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (isVipExtra((String) p.args[0])) {
                            try { p.setResult(true); }
                            catch (Throwable t) { XLog.w("intent.hasExtra: " + t); }
                        }
                    }
                });
            }
        });
        XLog.i("data-layer: Bundle/Intent extras hooked");
    }

    /** مفتاح VIP حقيقي؟ (يستثني مفاتيح الإحصائيات كما في طبقة prefs). */
    private static boolean isVipExtra(String key) {
        if (key == null) return false;
        try {
            String norm = key.toLowerCase(Locale.US).replace("_", "");
            if (Config.isAnalyticsKey(norm)) return false;
            return Config.isVipKey(norm);
        } catch (Throwable t) {
            return false;
        }
    }

    // ================================================================
    // ربط صنف واحد بالبصمة — مفوَّض إلى HookEngine (نفس السياسة)
    // ================================================================
    private static void hookClass(String name, ClassLoader cl) {
        try {
            ENGINE.hookClassByName(name, cl);
        } catch (Throwable t) {
            XLog.w("hookClass delegate: " + t);
        }
    }

    // (المعالجات المساعدة انتقلت إلى HookEngine مع Safe.coerceReturn)

    // ====== أداة ======
    private static File apkOf(Context ctx) {
        if (ctx == null) return null;
        try {
            String p = ctx.getPackageCodePath();
            if (p == null) return null;
            File f = new File(p);
            return f.isFile() ? f : null;
        } catch (Throwable t) { return null; }
    }

    private UnlockEngine() {}
}
