# Changelog

## v7.0.0 — 2026-10-16
- هوية جديدة: NexHookPro (`com.nexhook.pro`) — API 25 → 35
- مدخل موحد legacy `MainHook` + مدخل حديث `ModernHook` (libxposed 101 → 102)
- لا حزم ثابتة — كل الاعتماد على البصمة والانعكاس
- لا هوك على System.loadLibrary / Runtime.loadLibrary0 (درس libmmkv)
- ContextWrapper#attachBaseContext بدل Application (درس NoSuchMethodError)
- BaseBundle بدل Bundle للدوال الأساسية (درس NoSuchMethodError)
- AtomicBoolean + tryArm لمنع تكرار التنشيط وحلقة re-arm
- Safe.coerceReturn يمنع ClassCastException في كل فرض
- فلتر بنية تحتية صارم قبل أي forName (لا fancybypass/pairip)
- سجل `nexhook.log` + مفتاح طوارئ `nexhook_safe.flag`
- `hook_config.json` مشحون + `build.sh` ينتج APK + source ZIP
- ترقيات الدرجة: قيم انتهاء 2100، مطابقة TextView تامة

## v6.0.0 — LokTvHookPro (الجيل السابق)
- مدخل مزدوج أول + HookEngine مستخرج + منع re-arm + API 21+
- انظر `docs/ANALYSIS_LokTvHookPro_v6.0.0.md`

## v4.2.0 / v4.1.0 — LokTvHookPro (الأجيال الأولى)
- طبقات prefs/json/text/bundle + بصمة native + إعدادات تفاعلية
- انظر `docs/ANALYSIS_LokTvHookPro_v4.*.md`
