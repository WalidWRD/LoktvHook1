# NexHookPro v7.0.0

موديول Xposed احترافي — يعمل على **أي تطبيق** بلا أسماء حزم ثابتة.

> `NexHookPro v7.0.0 | Universal VIP unlock | reflection+fingerprint | API25-35 | safe | root & non-root`

## بطاقة الموديول

| البند | القيمة |
|---|---|
| الاسم | NexHookPro |
| الإصدار | 7.0.0 (versionCode 700) |
| الحزمة | `com.nexhook.pro` |
| أندرويد | API 25 (7.1) → API 35 (15) |
| libxposed | 101 → 102 (مدخل حديث + meta) |
| نقطة الدخول | `com.nexhook.pro.MainHook` |
| روت | LSPosed / EdXposed |
| بدون روت | NPatch / LSPatch / HKPatcher |

## المخرجات الجاهزة

| الملف | الوصف |
|---|---|
| `dist/NexHookPro-v7.0.0.apk` | الموديول موقّعاً (v1+v2+v3) — ثبّته مباشرة (تطبيق جديد، ليس ترقية) |
| `dist/NexHookPro-v7.0.0-src.zip` | السورس كود الكامل مع العدسات — يُبنى بـ `./build.sh` |
| `docs/ANALYSIS_NexHookPro_v7.0.0.md` | ملف التحليل والنتائج (المرجع الدائم) |
| `CHANGELOG.md` | سجل الإصدارات |
| `dist/LokTvHookPro-*`, `dist/NexHookPro-*` القديم | الأجيال السابقة (مرجع) |

## التثبيت

### بدون روت (NPatch / LSPatch / HKP)
1. ثبّت `NexHookPro-v7.0.0.apk`
2. افتحه مرة (شاشة التشخيص)
3. في المدير: فعّل NexHookPro
4. اختر APK الهدف ← Patch ← Install (احذف أصل الهدف)

### بروت (LSPosed)
1. ثبّت الموديول
2. فعّله في LSPosed وعلّم **أي** حزمة في النطاق
3. أعد تشغيل التطبيق الهدف

## السجل والطوارئ

- السجل: `<cacheDir>/nexhook.log` في الهدف (+ logcat وسجل LSPosed)
- الطوارئ: أنشئ `<cacheDir>/nexhook_safe.flag` في الهدف → يُوقف كل هوك المضيف
  (زر الشاشة يفعلها فوراً في وضع بدون روت)

## كيف يعمل (باختصار)

- **بلا أسماء ثابتة**: `classLoader` + انعكاس + بصمة (درجة A/B) + جرد DEX — أي حزمة، أي إصدار.
- **دروس ميدانية مطبقة**: لا loadLibrary (libmmkv)، ‏ContextWrapper لا Application،
  ‏BaseBundle لا Bundle، ‏coerceReturn ضد ClassCastException، منع re-arm، فلتر infra صارم.
- **قابل للصيانة**: كل شيء في `core/Config.java` — انظر `docs/ANALYSIS_NexHookPro_v7.0.0.md`.

## البناء

```bash
export ANDROID_HOME=/path/to/sdk
./build.sh
# الناتج:
#   dist/NexHookPro-v7.0.0.apk
#   dist/NexHookPro-v7.0.0-src.zip
```

كلمة سر المفتاح `nexhook2026` (عبر `NEXHOOK_KEY_PASS=...`) — **احتفظ بـ `keystore/`**.

## التحقق

```bash
apksigner verify --print-certs dist/NexHookPro-v7.0.0.apk
jarsigner -verify dist/NexHookPro-v7.0.0.apk
unzip -p dist/NexHookPro-v7.0.0.apk assets/xposed_init
```
