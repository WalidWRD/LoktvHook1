package com.nexhook.pro;

import android.os.Build;

import com.nexhook.pro.core.Config;
import com.nexhook.pro.core.LoaderCollector;
import com.nexhook.pro.core.UnlockEngine;
import com.nexhook.pro.core.XLog;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * نقطة الدخول الموحدة (legacy API-82 — تعمل مع كل الأُطر).
 * متوافقة مع libxposed 101→102 (وضع التوافق القديم + meta-data في Manifest).
 * لا تعتمد أي اسم حزمة: أي حزمة إلا الموديول نفسه.
 */
public class MainHook implements IXposedHookZygoteInit, IXposedHookLoadPackage {

    @Override
    public void initZygote(StartupParam sp) {
        try {
            XLog.i("zygote | modulePath=" + sp.modulePath + " | v=" + Config.VERSION);
        } catch (Throwable ignored) {}
        try {
            UnlockEngine.markStart();
        } catch (Throwable ignored) {}
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        try {
            if (lp == null) return;

            // أي حزمة إلا الموديول نفسه.
            String pkg = lp.packageName;
            if (pkg == null || pkg.isEmpty()) return;
            if (pkg.startsWith("com.nexhook.")) return;

            // حارس الإصدار: API 25+ بتسامح للأعلى.
            if (sdkInt() < Config.MIN_SDK) return;

            // العملية الرئيسية فقط (فرعHer: proc==pkg).
            String proc = lp.processName;
            if (proc != null && !proc.equals(pkg) && !proc.startsWith(pkg + ":")) {
                return;
            }

            try {
                XLog.i("target | pkg=" + pkg
                        + " | proc=" + proc
                        + " | firstApp=" + lp.isFirstApplication
                        + " | v=" + Config.VERSION);
            } catch (Throwable ignored) {}

            LoaderCollector.install(lp);

            final UnlockEngine eng = new UnlockEngine(pkg, lp.classLoader);
            eng.passive();

            // مؤقت تأجيل — حتى يجهز Context (attach أو 4 ثوانٍ).
            final long t0 = System.currentTimeMillis();
            Thread tick = new Thread(new Runnable() {
                @Override public void run() {
                    for (int i = 0; i < 40; i++) {
                        try { Thread.sleep(250); } catch (InterruptedException ignored) {}
                        try { eng.tick(System.currentTimeMillis() - t0); }
                        catch (Throwable ignored) {}
                    }
                }
            }, "nexhook-tick");
            try {
                tick.setDaemon(true);
                tick.start();
            } catch (Throwable ignored) {}

        } catch (Throwable t) {
            XLog.e("handleLoadPackage", t);
        }
    }

    private int sdkInt() {
        try {
            return Build.VERSION.SDK_INT;
        } catch (Throwable t) {
            return Config.MIN_SDK;
        }
    }
}
