package com.nexhook.pro.core;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import dalvik.system.BaseDexClassLoader;
import dalvik.system.PathClassLoader;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * جامع ClassLoader + جواسيس سلبية (مراقبة فقط — لا هوك نشط هنا).
 *
 * <p>إصلاح v7.0.0: attachBaseContext تُهوَّك على ContextWrapper (حيث تُعلَن فعلاً)
 * لا على Application (درس NoSuchMethodError)، مع فلتر instanceof Application.
 * لا هوك على System.loadLibrary إطلاقاً (درس libmmkv).
 */
public final class LoaderCollector {

    private static final List<WeakReference<ClassLoader>> LOADERS =
            Collections.synchronizedList(new ArrayList<WeakReference<ClassLoader>>());

    /** منع re-arm: كل loader يُسلَّح مرة واحدة (درس حلقة الضجيج). */
    private static final Set<Integer> ARMED =
            Collections.newSetFromMap(new ConcurrentHashMap<Integer, Boolean>());

    private static volatile boolean installed = false;

    private LoaderCollector() {}

    public static void register(ClassLoader cl) {
        if (cl == null) return;
        synchronized (LOADERS) {
            for (int i = 0; i < LOADERS.size(); i++) {
                if (LOADERS.get(i).get() == cl) return;
            }
            LOADERS.add(new WeakReference<ClassLoader>(cl));
        }
    }

    public static boolean tryArm(ClassLoader cl) {
        if (cl == null) return false;
        return ARMED.add(System.identityHashCode(cl));
    }

    public static int armedCount() {
        return ARMED.size();
    }

    /** نقطة دخول المسار الحديث (libxposed) — نفس منطق التسجيل. */
    public static void addExternal(ClassLoader cl, boolean real) {
        register(cl);
        if (real) {
            Ctx.setClassLoader(cl);
        }
    }

    public static List<ClassLoader> snapshot() {
        List<ClassLoader> out = new ArrayList<ClassLoader>();
        synchronized (LOADERS) {
            for (int i = 0; i < LOADERS.size(); i++) {
                ClassLoader cl = LOADERS.get(i).get();
                if (cl != null) out.add(cl);
            }
        }
        return out;
    }

    public static Set<ClassLoader> all() {
        return new HashSet<ClassLoader>(snapshot());
    }

    /**
     * الجواسيس السلبية للمسار القديم: Application.onCreate + Activity.onCreate +
     * منشئات PathClassLoader + ‏ActivityThread — مراقبة وجمع فقط.
     * (attachBaseContext يعيش في UnlockEngine.passive على ContextWrapper.)
     */
    public static void install(final XC_LoadPackage.LoadPackageParam lp) {
        if (installed) {
            register(lp.classLoader);
            return;
        }
        installed = true;
        Safe.run(new Runnable() {
            @Override public void run() {
                register(lp.classLoader);

                XposedHelpers.findAndHookMethod(Application.class, "onCreate",
                        new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        try {
                            Application a = (Application) p.thisObject;
                            Ctx.set(a);
                            register(a.getClassLoader());
                            Ctx.setClassLoader(a.getClassLoader());
                            XLog.i("loader collected: " + a.getClassLoader());
                        } catch (Throwable t) {
                            XLog.w("onCreate spy: " + t);
                        }
                    }
                });

                XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class,
                        new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        try {
                            Activity a = (Activity) p.thisObject;
                            Ctx.set(a);
                            register(a.getClassLoader());
                            Ctx.setClassLoader(a.getClassLoader());
                        } catch (Throwable t) {
                            XLog.w("activity spy: " + t);
                        }
                    }
                });

                try {
                    XposedBridge.hookAllConstructors(PathClassLoader.class,
                            new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            try {
                                ClassLoader cl = (ClassLoader) p.thisObject;
                                register(cl);
                                Ctx.setClassLoader(cl);
                            } catch (Throwable t) {
                                XLog.w("pathloader spy: " + t);
                            }
                        }
                    });
                } catch (Throwable ignored) {}

                try {
                    Class<?> at = Class.forName("android.app.ActivityThread");
                    XposedHelpers.findAndHookMethod(at, "currentApplication",
                            new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            try {
                                Application a = (Application) p.getResult();
                                if (a != null) {
                                    Ctx.set(a);
                                    register(a.getClassLoader());
                                    Ctx.setClassLoader(a.getClassLoader());
                                }
                            } catch (Throwable t) {
                                XLog.w("activitythread spy: " + t);
                            }
                        }
                    });
                } catch (Throwable ignored) {}

                XLog.d("watching loaders incl. "
                        + BaseDexClassLoader.class.getSimpleName()
                        + " + " + ContextWrapper.class.getSimpleName());
            }
        });
        register(lp.classLoader);
    }
}
