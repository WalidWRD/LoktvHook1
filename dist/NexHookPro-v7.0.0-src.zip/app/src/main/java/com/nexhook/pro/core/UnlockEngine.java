package com.nexhook.pro.core;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * v7.0.0 — يعمل على أي حزمة.
 *  • لا هوك على fancybypass/pairip (فلتر isForbidden قبل أي forName).
 *  • لا هوك على System.loadLibrary / Runtime.loadLibrary0 إطلاقاً.
 *  • ContextWrapper#attachBaseContext (لا Application — درس NoSuchMethodError).
 *  • BaseBundle للدوال الأساسية (لا Bundle — درس NoSuchMethodError).
 *  • AtomicBoolean + tryArm لمنع تكرار التنشيط.
 */
public final class UnlockEngine {

    private static final AtomicBoolean ACTIVATED = new AtomicBoolean(false);
    private static long startMs = System.currentTimeMillis();

    private final String pkg;
    private final ClassLoader loader;
    private final HookEngine engine = new HookEngine();

    public UnlockEngine(String pkg, ClassLoader loader) {
        this.pkg = pkg;
        this.loader = loader;
    }

    public static void markStart() { startMs = System.currentTimeMillis(); }

    // =====================================================================
    //  المرحلة السلبية — لا تمس كود المضيف إطلاقاً
    // =====================================================================
    public void passive() {
        LoaderCollector.register(loader);
        hookContextWrapperAttach();
        XLog.i("passive | pkg=" + pkg);
    }

    private void hookContextWrapperAttach() {
        try {
            XposedHelpers.findAndHookMethod(
                    ContextWrapper.class, "attachBaseContext", Context.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            try {
                                Object thiz = p.thisObject;
                                if (!(thiz instanceof Application)) return;
                                Context c = (Context) p.args[0];
                                Ctx.set(c);
                                XLog.i("Application.attachBaseContext → ctx set");
                                tryActivate();
                            } catch (Throwable ignored) {}
                        }
                    });
        } catch (Throwable t) {
            XLog.w("attachBaseContext hook: " + t);
        }
    }

    public void tick(long elapsed) {
        if (Ctx.get() != null) { tryActivate(); return; }
        if (elapsed >= Config.ACTIVATION_DELAY_MS) {
            XLog.i("timeout activation " + elapsed + "ms");
            tryActivate();
        }
    }

    // =====================================================================
    //  المرحلة النشطة — مرة واحدة فقط
    // =====================================================================
    private void tryActivate() {
        if (!LoaderCollector.tryArm(loader)) return;
        if (!ACTIVATED.compareAndSet(false, true)) return;
        Safe.run(new Runnable() {
            @Override public void run() { activate(); }
        });
    }

    private void activate() {
        long t0 = System.currentTimeMillis();
        boolean hasCtx = false;
        try { hasCtx = (Ctx.get() != null); } catch (Throwable ignored) {}
        XLog.i("=== activate | ctx=" + hasCtx + " ===");

        Context ctx = Ctx.get();
        if (ctx != null) {
            try { XLog.setLogFile(new File(ctx.getCacheDir(), Config.LOG_FILE)); }
            catch (Throwable ignored) {}
            SignatureCheck.report(ctx, pkg);

            try {
                if (new File(ctx.getCacheDir(), Config.EMERGENCY_FLAG).exists()) {
                    XLog.w("emergency flag — host hooks disabled");
                    return;
                }
            } catch (Throwable ignored) {}
        }

        // 1) الجرد من base.apk مباشرة (بلا انعكاس)
        Set<String> inventory = Safe.call(new Safe.Producer<Set<String>>() {
            @Override public Set<String> produce() throws Throwable {
                File apk = resolveApk(Ctx.get());
                if (apk == null) return null;
                XLog.i("inventory apk=" + apk.getAbsolutePath());
                return DexNames.scanApk(apk);
            }
        }, null);

        int names = (inventory == null) ? 0 : inventory.size();
        XLog.i("inventory names=" + names);

        // 2) التصنيف + الهوك بحد زمني
        int scanned = 0, tierA = 0, tierB = 0;
        if (inventory != null) {
            for (String cls : inventory) {
                if (scanned >= Config.MAX_CLASSES_SCAN) break;
                if (System.currentTimeMillis() - t0 > Config.SCAN_TIME_BUDGET_MS) {
                    XLog.w("scan budget exceeded");
                    break;
                }
                scanned++;
                if (Config.isForbidden(cls)) continue;

                int tier = Fingerprint.classify(cls);
                if (tier == 0) continue;

                Class<?> c = Reflect.forNameSafe(cls, loader);
                if (c == null) continue;
                engine.hookClass(c, tier);
                if (tier == 1) tierA++; else tierB++;
            }
        }

        // 3) طبقات ثابتة (لا تعتمد على الدرجة)
        Safe.run(new Runnable() {
            @Override public void run() { hookPrefs(); }
        });
        Safe.run(new Runnable() {
            @Override public void run() { hookJson(); }
        });
        Safe.run(new Runnable() {
            @Override public void run() { hookBundle(); }
        });
        Safe.run(new Runnable() {
            @Override public void run() { hookText(); }
        });

        XLog.i("SUMMARY | pkg=" + pkg
                + " | hooks=" + engine.hookCount()
                + " | classes=" + engine.classCount()
                + " | inventory=" + names
                + " | tierA=" + tierA + " tierB=" + tierB
                + " | scanned=" + scanned
                + " | v=" + Config.VERSION);
    }

    private File resolveApk(Context ctx) {
        if (ctx == null) return null;
        try {
            String src = ctx.getApplicationInfo().sourceDir;
            if (src != null) {
                File f = new File(src);
                if (f.isFile()) return f;
            }
            String pub = ctx.getApplicationInfo().publicSourceDir;
            if (pub != null) {
                File f = new File(pub);
                if (f.isFile()) return f;
            }
        } catch (Throwable ignored) {}
        return null;
    }

    // =====================================================================
    //  طبقة SharedPreferences (getBoolean/getInt/getLong/getString)
    // =====================================================================
    private void hookPrefs() {
        try {
            Class<?> c = Class.forName("android.app.SharedPreferencesImpl");

            hookAfter(c, "getBoolean", new Class<?>[]{String.class, boolean.class},
                    new AfterCb() {
                        @Override public void run(Method m, XC_MethodHook.MethodHookParam p) {
                            String k = (String) p.args[0];
                            if (Config.isVipKey(k) && !Boolean.TRUE.equals(p.getResult()))
                                p.setResult(Safe.coerceReturn(m, Boolean.TRUE));
                        }
                    });

            hookAfter(c, "getInt", new Class<?>[]{String.class, int.class},
                    new AfterCb() {
                        @Override public void run(Method m, XC_MethodHook.MethodHookParam p) {
                            String k = (String) p.args[0];
                            if (Config.isVipKey(k)) {
                                long v = Config.isExpiryName(k)
                                        ? Config.VALUE_LONG_EXPIRE : Config.VALUE_LONG_DEFAULT;
                                p.setResult(Safe.coerceReturn(m, v));
                            }
                        }
                    });

            hookAfter(c, "getLong", new Class<?>[]{String.class, long.class},
                    new AfterCb() {
                        @Override public void run(Method m, XC_MethodHook.MethodHookParam p) {
                            String k = (String) p.args[0];
                            if (Config.isVipKey(k)) {
                                long v = Config.isExpiryName(k)
                                        ? Config.VALUE_LONG_EXPIRE : Config.VALUE_LONG_DEFAULT;
                                p.setResult(Safe.coerceReturn(m, v));
                            }
                        }
                    });

            hookAfter(c, "getString", new Class<?>[]{String.class, String.class},
                    new AfterCb() {
                        @Override public void run(Method m, XC_MethodHook.MethodHookParam p) {
                            String k = (String) p.args[0];
                            if (Config.isVipKey(k))
                                p.setResult(Safe.coerceReturn(m, Config.VALUE_STRING_VIP));
                        }
                    });

            XLog.i("prefs-layer: SharedPreferencesImpl hooked");
        } catch (Throwable t) {
            XLog.w("prefs hook: " + t);
        }
    }

    // =====================================================================
    //  طبقة org.json (getBoolean/optBoolean/getInt/optInt)
    // =====================================================================
    private void hookJson() {
        try {
            Class<?> c = Class.forName("org.json.JSONObject");
            String[] boolNames = {"getBoolean", "optBoolean"};
            for (int i = 0; i < boolNames.length; i++) {
                final String n = boolNames[i];
                hookAfter(c, n, new Class<?>[]{String.class},
                        new AfterCb() {
                            @Override public void run(Method m, XC_MethodHook.MethodHookParam p) {
                                String k = (String) p.args[0];
                                if (Config.isVipKey(k))
                                    p.setResult(Safe.coerceReturn(m, Boolean.TRUE));
                            }
                        });
            }
            String[] intNames = {"getInt", "optInt"};
            for (int i = 0; i < intNames.length; i++) {
                final String n = intNames[i];
                hookAfter(c, n, new Class<?>[]{String.class},
                        new AfterCb() {
                            @Override public void run(Method m, XC_MethodHook.MethodHookParam p) {
                                String k = (String) p.args[0];
                                if (Config.isVipKey(k))
                                    p.setResult(Safe.coerceReturn(m, Config.VALUE_LONG_DEFAULT));
                            }
                        });
            }
            XLog.i("json-layer: JSONObject hooked");
        } catch (Throwable t) {
            XLog.w("json hook: " + t);
        }
    }

    // =====================================================================
    //  طبقة Bundle — الدوال الأساسية على BaseBundle (درس NoSuchMethodError)
    // =====================================================================
    private void hookBundle() {
        try {
            Class<?> base = Class.forName("android.os.BaseBundle");

            hookAfter(base, "getBoolean", new Class<?>[]{String.class},
                    new AfterCb() {
                        @Override public void run(Method m, XC_MethodHook.MethodHookParam p) {
                            String k = (String) p.args[0];
                            if (Config.isVipKey(k) && !Boolean.TRUE.equals(p.getResult()))
                                p.setResult(Safe.coerceReturn(m, Boolean.TRUE));
                        }
                    });

            hookAfter(base, "getInt", new Class<?>[]{String.class},
                    new AfterCb() {
                        @Override public void run(Method m, XC_MethodHook.MethodHookParam p) {
                            String k = (String) p.args[0];
                            if (Config.isVipKey(k)) {
                                long v = Config.isExpiryName(k)
                                        ? Config.VALUE_LONG_EXPIRE : Config.VALUE_LONG_DEFAULT;
                                p.setResult(Safe.coerceReturn(m, v));
                            }
                        }
                    });

            hookAfter(base, "containsKey", new Class<?>[]{String.class},
                    new AfterCb() {
                        @Override public void run(Method m, XC_MethodHook.MethodHookParam p) {
                            String k = (String) p.args[0];
                            if (Config.isVipKey(k) && !Boolean.TRUE.equals(p.getResult()))
                                p.setResult(Safe.coerceReturn(m, Boolean.TRUE));
                        }
                    });

            Class<?> bundle = Class.forName("android.os.Bundle");
            hookAfter(bundle, "getString", new Class<?>[]{String.class},
                    new AfterCb() {
                        @Override public void run(Method m, XC_MethodHook.MethodHookParam p) {
                            String k = (String) p.args[0];
                            if (Config.isVipKey(k))
                                p.setResult(Safe.coerceReturn(m, Config.VALUE_STRING_VIP));
                        }
                    });

            XLog.i("bundle-layer: BaseBundle/Bundle hooked");
        } catch (Throwable t) {
            XLog.w("bundle hook: " + t);
        }
    }

    // =====================================================================
    //  طبقة الواجهة — مطابقة تامة من جدول Config
    // =====================================================================
    private void hookText() {
        try {
            Class<?> tv = Class.forName("android.widget.TextView");
            Method m = Reflect.findMethod(tv, "setText", CharSequence.class);
            if (m == null) return;
            XposedBridge.hookMethod(m, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        Object a = p.args[0];
                        if (!(a instanceof CharSequence)) return;
                        String s = a.toString();
                        for (int i = 0; i < Config.TEXT_REPLACEMENTS.length; i++) {
                            String[] r = Config.TEXT_REPLACEMENTS[i];
                            if (r.length == 2 && r[0].equals(s)) {
                                p.args[0] = r[1];
                                return;
                            }
                        }
                    } catch (Throwable ignored) {}
                }
            });
            XLog.i("text-layer: TextView.setText hooked");
        } catch (Throwable t) {
            XLog.w("text hook: " + t);
        }
    }

    // =====================================================================
    //  أداة after-hook موحدة
    // =====================================================================
    private interface AfterCb {
        void run(Method m, XC_MethodHook.MethodHookParam p);
    }

    private void hookAfter(Class<?> c, String name, Class<?>[] params, AfterCb cb) {
        Method m = Reflect.findMethod(c, name, params);
        if (m == null) return;
        try {
            XposedBridge.hookMethod(m, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try { cb.run((Method) p.method, p); }
                    catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }
}
