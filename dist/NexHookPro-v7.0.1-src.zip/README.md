# NexHookPro v7.0.1

موديول Xposed احترافي — يعمل على **أي تطبيق** بلا أسماء حزم ثابتة.

> `NexHookPro v7.0.1 | Universal VIP unlock | reflection+fingerprint | API25-35 | safe | root & non-root`

## بطاقة الموديول

| البند | القيمة |
|---|---|
| الاسم | NexHookPro |
| الإصدار | 7.0.1 (versionCode 701) |
| الحزمة | `com.nexhook.pro` |
| أندرويد | API 25 (7.1) → API 35 (15) |
| libxposed | 101 → 102 (مدخل حديث + meta) |
| نقطة الدخول | `com.nexhook.pro.MainHook` |
| روت | LSPosed / EdXposed |
| بدون روت | NPatch / LSPatch / HKPatcher |

## الجديد في v7.0.1 (إصلاح انهيار androidx.startup)

- **حذف كل هوك ClassLoader** — لا BaseDexClassLoader، لا loadClass، لا findClass.
- التنشيط **بعد `Application.onCreate`** (بعد installContentProviders) بدل attachBaseContext.
- `attachBaseContext` يخزّن Context فقط عبر `setRaw` (بلا getApplicationContext).
- التنشيط على Thread منفصل + fallback أول Activity + timeout 8s.
- قراءة `base.apk` الحقيقي عند fancy wrapper.

## المخرجات الجاهزة

| الملف | الوصف |
|---|---|
| `dist/NexHookPro-v7.0.1.apk` | الموديول موقّعاً (v1+v2+v3) — ترقية مباشرة فوق v7.0.0 (نفس التوقيع) |
| `dist/NexHookPro-v7.0.1-src.zip` | السورس كود الكامل مع العدسات — يُبنى بـ `./build.sh` |
| `docs/ANALYSIS_NexHookPro_v7.0.1.md` | ملف التحليل والنتائج (مع ملف v7.0.0) |
| `CHANGELOG.md` | سجل الإصدارات |

## التثبيت

### بدون روت (NPatch / LSPatch / HKP)
1. ثبّت `NexHookPro-v7.0.1.apk`
2. افتحه مرة
3. في المدير: Modules ← فعّل NexHookPro
4. اختر APK الهدف ← Patch ← Install

### بروت (LSPosed)
1. ثبّت الموديول (ترقية مباشرة فوق v7.0.0)
2. فعّله في LSPosed
3. علّم **أي** حزمة في النطاق
4. أعد تشغيل التطبيق الهدف

## السجل والطوارئ

- السجل: `<cacheDir>/nexhook.log` في الهدف (+ logcat وسجل LSPosed)
- الطوارئ: أنشئ `<cacheDir>/nexhook_safe.flag` في الهدف → يُوقف كل هوك المضيف

## البناء

```bash
export ANDROID_HOME=/path/to/sdk
./build.sh
# الناتج:
#   dist/NexHookPro-v7.0.1.apk
#   dist/NexHookPro-v7.0.1-source.zip → dist/NexHookPro-v7.0.1-src.zip
```

كلمة سر المفتاح `nexhook2026` (عبر `NEXHOOK_KEY_PASS=...`) — **احتفظ بـ `keystore/`**.

## الصيانة

كل التعديلات في `src/main/java/com/nexhook/pro/core/Config.java` — انظر `docs/ANALYSIS_NexHookPro_v7.0.1.md`.

## التحقق

```bash
apksigner verify --print-certs dist/NexHookPro-v7.0.1.apk
jarsigner -verify dist/NexHookPro-v7.0.1.apk
unzip -p dist/NexHookPro-v7.0.1.apk assets/xposed_init
```
